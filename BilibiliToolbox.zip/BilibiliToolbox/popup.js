// Bilibili Toolbox - popup script

let cachedData = createDefaultData();

document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
    loadData();
    chrome.storage.onChanged.addListener(handleStorageChange);
});

function loadData() {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
        applyData(result[STORAGE_KEY]);
    });
}

function applyData(data) {
    cachedData = normalizeToolboxData(data);
    renderFavorites();
}

function saveFavorites(callback) {
    chrome.storage.local.set({ [STORAGE_KEY]: cachedData }, callback);
}

function handleStorageChange(changes, areaName) {
    if (areaName !== 'local' || !changes[STORAGE_KEY]) return;
    applyData(changes[STORAGE_KEY].newValue);
}

function renderFavoriteItem(item) {
    const favoriteKey = getFavoriteKey(item);
    const name = escapeHtml(getFavoriteName(item));
    const image = escapeHtml(getFavoriteImage(item));
    const link = escapeHtml(getFavoriteLink(item));
    const type = isReadlistFavorite(item) ? '专栏' : '空间';

    return `<div class="user-item">
        <div class="user-info">
            <img src="${image}" alt="${name}" class="user-avatar">
            <span class="user-name">${name}</span>
        </div>
        <div class="user-actions">
            <a href="${link}" target="_blank" rel="noopener noreferrer" class="user-link">${type}</a>
            <button type="button" class="delete-btn" data-key="${escapeHtml(favoriteKey)}">删除</button>
        </div>
    </div>`;
}

function renderFavorites() {
    const userList = document.getElementById('userList');
    if (!userList) return;

    const favorites = cachedData.favorites || [];
    userList.innerHTML = favorites.length === 0
        ? '<div class="empty-tip">暂无收藏</div>'
        : favorites.map(renderFavoriteItem).join('');
}

function deleteFavorite(favoriteKey) {
    const filtered = cachedData.favorites.filter(item => getFavoriteKey(item) !== favoriteKey);
    if (filtered.length === cachedData.favorites.length) return;

    cachedData.favorites = filtered;
    saveFavorites(renderFavorites);
}

function setupEventListeners() {
    document.getElementById('userList')?.addEventListener('click', (event) => {
        const key = event.target.closest('.delete-btn')?.dataset.key;
        if (key) deleteFavorite(key);
    });

    document.getElementById('addCurrentBtn')?.addEventListener('click', addCurrentFavorite);
}

async function getPageFavoriteData(tabId, uid) {
    let pageData = {};

    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
                const extractUserNameFromMeta = () => {
                    const title = document.title || '';
                    const keywords = document.querySelector('meta[name="keywords"]')?.content || '';
                    const description = document.querySelector('meta[name="description"]')?.content || '';
                    const profileSuffixPattern = '(?:\\u7684)?\\u4e2a\\u4eba(?:\\u52a8\\u6001|\\u7a7a\\u95f4|\\u4e3b\\u9875)';

                    return (
                        title.match(new RegExp(`^(.+?)${profileSuffixPattern}`))?.[1]
                        || keywords.match(new RegExp(`^(.+?)${profileSuffixPattern}`))?.[1]
                        || description.match(/\u54d4\u54e9\u54d4\u54e9(.+?)\u7684\u4e2a\u4eba(?:\u52a8\u6001|\u7a7a\u95f4)/)?.[1]
                        || description.match(/\u5173\u6ce8(.+?)\u8d26\u53f7/)?.[1]
                        || ''
                    ).trim();
                };
                const nameEl = document.querySelector('.user-name, .user-name-shadow, .name, [data-uname]');
                const faceEl = document.querySelector('.user-face img, .avatar img, [class*="face"] img, [data-face]');
                return {
                    uname: nameEl?.textContent?.trim() || nameEl?.getAttribute('data-uname') || extractUserNameFromMeta() || '',
                    face: faceEl?.src || faceEl?.getAttribute('data-face') || ''
                };
            }
        });

        pageData = results?.[0]?.result || {};
    } catch (_) {}

    return {
        type: USER_TYPE,
        uid,
        uname: pageData.uname || `用户 ${uid}`,
        face: pageData.face || ''
    };
}

function addCurrentFavorite() {
    chrome.tabs.query({ active: true, currentWindow: true }, async ([tab]) => {
        const url = tab?.url;
        if (!url?.includes(BILIBILI_DOMAIN)) {
            alert('请在 B 站页面使用此功能');
            return;
        }

        const uid = extractUidFromUrl(url);
        if (!uid) {
            alert('无法获取当前页面用户信息');
            return;
        }

        const favoriteKey = `${USER_TYPE}:${uid}`;
        if (cachedData.favorites.some(item => getFavoriteKey(item) === favoriteKey)) {
            alert('已在收藏列表');
            return;
        }

        const newFavorite = await getPageFavoriteData(tab.id, uid);
        cachedData.favorites = [...cachedData.favorites, newFavorite];
        saveFavorites(() => {
            alert(`已添加 ${newFavorite.uname} 到收藏列表`);
            renderFavorites();
        });
    });
}
